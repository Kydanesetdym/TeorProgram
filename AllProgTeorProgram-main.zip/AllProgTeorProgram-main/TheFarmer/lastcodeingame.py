#пока не прошел
size = 12

while True:
	for x in range(size):
		for y in range(size):

			# Проверяем землю
			if get_ground_type() != Grounds.Soil:
				till()

			# Сажаем новую тыкву, если тыквы нет
			# или она испорчена
			if get_entity_type() != Entities.Pumpkin:
				plant(Entities.Pumpkin)

			# Собираем созревшие тыквы
			elif can_harvest():
				harvest()
				plant(Entities.Pumpkin)

			# Движение змейкой
			if x % 2 == 0:
				if y < size - 1:
					move(North)
			else:
				if y < size - 1:
					move(South)

		# Переходим в следующий столбец
		if x < size - 1:
			move(East)